from django.shortcuts import render
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from .models import Photo

@csrf_exempt
def upload_photo(request):
    if request.method == 'POST':
        title = request.POST.get('title')
        image = request.FILES.get('image')
        if title and image:
            photo = Photo.objects.create(title=title, image=image)
            return JsonResponse({'message': 'Photo uploaded successfully', 'photo_id': photo.id})
        return JsonResponse({'error': 'Title or image missing'}, status=400)
    return JsonResponse({'error': 'Invalid request method'}, status=405)

def get_all_photos(request):
    if request.method == 'GET':
        photos = Photo.objects.all()
        photo_list = [
            {
                'id': photo.id,
                'title': photo.title,
                'image_url': request.build_absolute_uri(photo.image.url)
            }
            for photo in photos
        ]
        return JsonResponse({'photos': photo_list})
    return JsonResponse({'error': 'Invalid request method'}, status=405)

def get_all_photos_html(request):
    photos = Photo.objects.all()
    return render(request, 'blog/photo_list.html', {'photos': photos})
