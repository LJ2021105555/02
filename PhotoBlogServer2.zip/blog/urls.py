from django.urls import path
from .views import upload_photo, get_all_photos

urlpatterns = [
    path('upload/', upload_photo, name='upload_photo'),
    path('photos/', get_all_photos, name='get_all_photos'),
]